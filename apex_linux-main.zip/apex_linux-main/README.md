# apex_linux  
git clone https://github.com/ekknod/apex_linux --recursive  
cd apex_linux  
./run  
